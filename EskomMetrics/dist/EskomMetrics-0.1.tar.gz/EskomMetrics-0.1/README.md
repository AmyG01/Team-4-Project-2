# Team-4-Project-2
Building functions to calculate metrics using eskom data
